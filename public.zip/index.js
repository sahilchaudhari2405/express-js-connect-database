const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.static('public'));
app.post('/', (req, res) => {
    res.redirect(__dirname+"/public/index.html");
}); 

app.listen(PORT, () => console.log(`Server listening on port: ${PORT}`));